<?php
/**
 * As configurações básicas do WordPress
 *
 * O script de criação wp-config.php usa esse arquivo durante a instalação.
 * Você não precisa usar o site, você pode copiar este arquivo
 * para "wp-config.php" e preencher os valores.
 *
 * Este arquivo contém as seguintes configurações:
 *
 * * Configurações do MySQL
 * * Chaves secretas
 * * Prefixo do banco de dados
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Configurações do MySQL - Você pode pegar estas informações com o serviço de hospedagem ** //
/** O nome do banco de dados do WordPress */
define( 'DB_NAME', 'wp_teste-cloudopss' );

/** Usuário do banco de dados MySQL */
define( 'DB_USER', 'root' );

/** Senha do banco de dados MySQL */
define( 'DB_PASSWORD', '' );

/** Nome do host do MySQL */
define( 'DB_HOST', 'localhost' );

/** Charset do banco de dados a ser usado na criação das tabelas. */
define( 'DB_CHARSET', 'utf8mb4' );

/** O tipo de Collate do banco de dados. Não altere isso se tiver dúvidas. */
define( 'DB_COLLATE', '' );

/**#@+
 * Chaves únicas de autenticação e salts.
 *
 * Altere cada chave para um frase única!
 * Você pode gerá-las
 * usando o {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org
 * secret-key service}
 * Você pode alterá-las a qualquer momento para invalidar quaisquer
 * cookies existentes. Isto irá forçar todos os
 * usuários a fazerem login novamente.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'M~?Bg=~N*pXF,|]i#fVa4^pJri<3Q&clyYk4KGbZc7`{$$;_|`PJNSe~~e:]syJC' );
define( 'SECURE_AUTH_KEY',  'v:]pHD[CL)_k*$c8IdnL(}wa-:t3H#_c0?S;@2W9NoAfvCj9p|=o<>D/Un0[3z&]' );
define( 'LOGGED_IN_KEY',    '~97*}f.@=VYB.`ufD,ebg.L`Ws{Lgd#n}l{n[Es%~A**3U!X#@yE#m~Si>x,|c=E' );
define( 'NONCE_KEY',        'SQo.,taUDckJ?aJ?:E<Z62O0v;KS!PK`[ih(![Aa:#_6{l?+zIunMB$zeQ5Yp$Q+' );
define( 'AUTH_SALT',        'o~^# -Z7|Z 2J%b>%w!ToXA!#U2PTMqu(i?5H:CPx5q{SUS#4Of5.$v;~^8T%_SG' );
define( 'SECURE_AUTH_SALT', '@kaY^!2;B1CMsB{tut=52)1zs]:!5PR&q+qI)gY)spG>z}6r1?rL,RAxUG$jm^O&' );
define( 'LOGGED_IN_SALT',   'JK;$s6;-vx*o9<[LpS%]ktf?*x{b.4*Sp,C+Z`wkxz}w+h(TYyS}G-Gj@1E!5?%,' );
define( 'NONCE_SALT',       'e.]FTL?eifb%---XE@JnK16>|ZT-|&6 }Gv07ab^uYjgoVszCOUK8b99gGKpy|m.' );

/**#@-*/

/**
 * Prefixo da tabela do banco de dados do WordPress.
 *
 * Você pode ter várias instalações em um único banco de dados se você der
 * um prefixo único para cada um. Somente números, letras e sublinhados!
 */
$table_prefix = 'wp_';

/**
 * Para desenvolvedores: Modo de debug do WordPress.
 *
 * Altere isto para true para ativar a exibição de avisos
 * durante o desenvolvimento. É altamente recomendável que os
 * desenvolvedores de plugins e temas usem o WP_DEBUG
 * em seus ambientes de desenvolvimento.
 *
 * Para informações sobre outras constantes que podem ser utilizadas
 * para depuração, visite o Codex.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Isto é tudo, pode parar de editar! :) */

/** Caminho absoluto para o diretório WordPress. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Configura as variáveis e arquivos do WordPress. */
require_once ABSPATH . 'wp-settings.php';
